﻿namespace studentfeemanagmentsystem
{
    partial class welcome
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.sUBMITESTUDENTFEEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dELETESTUDENTRECORDToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.uPDATESTUDENTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sEARCHSTUDENTRECORDToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fINALREPORTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.logoutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sUBMITESTUDENTFEEToolStripMenuItem,
            this.dELETESTUDENTRECORDToolStripMenuItem,
            this.uPDATESTUDENTToolStripMenuItem,
            this.sEARCHSTUDENTRECORDToolStripMenuItem,
            this.fINALREPORTToolStripMenuItem,
            this.logoutToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1144, 24);
            this.menuStrip1.TabIndex = 4;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // sUBMITESTUDENTFEEToolStripMenuItem
            // 
            this.sUBMITESTUDENTFEEToolStripMenuItem.Image = global::studentfeemanagmentsystem.Properties.Resources.Administrator_icon2;
            this.sUBMITESTUDENTFEEToolStripMenuItem.Name = "sUBMITESTUDENTFEEToolStripMenuItem";
            this.sUBMITESTUDENTFEEToolStripMenuItem.Size = new System.Drawing.Size(138, 20);
            this.sUBMITESTUDENTFEEToolStripMenuItem.Text = "Submit Student Fee";
            this.sUBMITESTUDENTFEEToolStripMenuItem.Click += new System.EventHandler(this.sUBMITESTUDENTFEEToolStripMenuItem_Click);
            // 
            // dELETESTUDENTRECORDToolStripMenuItem
            // 
            this.dELETESTUDENTRECORDToolStripMenuItem.Image = global::studentfeemanagmentsystem.Properties.Resources.Actions_window_close_icon3;
            this.dELETESTUDENTRECORDToolStripMenuItem.Name = "dELETESTUDENTRECORDToolStripMenuItem";
            this.dELETESTUDENTRECORDToolStripMenuItem.Size = new System.Drawing.Size(152, 20);
            this.dELETESTUDENTRECORDToolStripMenuItem.Text = "Delete Student Record";
            this.dELETESTUDENTRECORDToolStripMenuItem.Click += new System.EventHandler(this.dELETESTUDENTRECORDToolStripMenuItem_Click);
            // 
            // uPDATESTUDENTToolStripMenuItem
            // 
            this.uPDATESTUDENTToolStripMenuItem.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.uPDATESTUDENTToolStripMenuItem.Image = global::studentfeemanagmentsystem.Properties.Resources.Actions_edit_clear_history_icon2;
            this.uPDATESTUDENTToolStripMenuItem.Name = "uPDATESTUDENTToolStripMenuItem";
            this.uPDATESTUDENTToolStripMenuItem.Size = new System.Drawing.Size(113, 20);
            this.uPDATESTUDENTToolStripMenuItem.Text = "Update Record";
            this.uPDATESTUDENTToolStripMenuItem.Click += new System.EventHandler(this.uPDATESTUDENTToolStripMenuItem_Click);
            // 
            // sEARCHSTUDENTRECORDToolStripMenuItem
            // 
            this.sEARCHSTUDENTRECORDToolStripMenuItem.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.sEARCHSTUDENTRECORDToolStripMenuItem.Image = global::studentfeemanagmentsystem.Properties.Resources.Actions_edit_find_user_icon2;
            this.sEARCHSTUDENTRECORDToolStripMenuItem.Name = "sEARCHSTUDENTRECORDToolStripMenuItem";
            this.sEARCHSTUDENTRECORDToolStripMenuItem.Size = new System.Drawing.Size(154, 20);
            this.sEARCHSTUDENTRECORDToolStripMenuItem.Text = "Search Student Record";
            this.sEARCHSTUDENTRECORDToolStripMenuItem.Click += new System.EventHandler(this.sEARCHSTUDENTRECORDToolStripMenuItem_Click);
            // 
            // fINALREPORTToolStripMenuItem
            // 
            this.fINALREPORTToolStripMenuItem.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.fINALREPORTToolStripMenuItem.Image = global::studentfeemanagmentsystem.Properties.Resources.Places_repository_icon1;
            this.fINALREPORTToolStripMenuItem.Name = "fINALREPORTToolStripMenuItem";
            this.fINALREPORTToolStripMenuItem.Size = new System.Drawing.Size(98, 20);
            this.fINALREPORTToolStripMenuItem.Text = "Final Report";
            this.fINALREPORTToolStripMenuItem.Click += new System.EventHandler(this.fINALREPORTToolStripMenuItem_Click);
            // 
            // logoutToolStripMenuItem
            // 
            this.logoutToolStripMenuItem.Image = global::studentfeemanagmentsystem.Properties.Resources.Accept_icon;
            this.logoutToolStripMenuItem.Name = "logoutToolStripMenuItem";
            this.logoutToolStripMenuItem.Size = new System.Drawing.Size(64, 20);
            this.logoutToolStripMenuItem.Text = "Close";
            this.logoutToolStripMenuItem.Click += new System.EventHandler(this.logoutToolStripMenuItem_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Georgia", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(301, 58);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(537, 38);
            this.label1.TabIndex = 5;
            this.label1.Text = "STUDENT FEES MANAGMENT ";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::studentfeemanagmentsystem.Properties.Resources.homep;
            this.pictureBox1.Location = new System.Drawing.Point(210, 172);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(696, 422);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 11;
            this.pictureBox1.TabStop = false;
            // 
            // welcome
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Inherit;
            this.BackColor = System.Drawing.Color.DarkTurquoise;
            this.ClientSize = new System.Drawing.Size(1144, 689);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "welcome";
            this.Text = "Techrover Solutions";
            this.Load += new System.EventHandler(this.welcome_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStripMenuItem sUBMITESTUDENTFEEToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dELETESTUDENTRECORDToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem uPDATESTUDENTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sEARCHSTUDENTRECORDToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fINALREPORTToolStripMenuItem;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem logoutToolStripMenuItem;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}