﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace studentfeemanagmentsystem
{
    public partial class delete : Form
    {
        string strcon = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|\\Techrover.mdb;Mode=ReadWrite;Persist Security Info=False";
        public delete()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                OleDbConnection con = new OleDbConnection(strcon);
                con.Open();

                int rowID = int.Parse(textBox1.Text);
                string qry = "DELETE FROM Student WHERE ID =" + rowID + "";
                OleDbCommand cmd = new OleDbCommand(qry, con);
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Record Delete Successfully");

                using (OleDbConnection newcon = new OleDbConnection(strcon))
                {
                    string sqlQuery = @"SELECT * from Student";
                    OleDbCommand cnd = new OleDbCommand(sqlQuery, newcon);
                    OleDbDataAdapter da = new OleDbDataAdapter(cnd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dataGridView1.DataSource = new BindingSource(dt, null);
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                MessageBox.Show("Please Enter Numbers in Student Id");
            }
        }

        public void Method()
        {
            throw new System.NotImplementedException();
        }

        private void delete_Load(object sender, EventArgs e)
        {
            OleDbConnection con = new OleDbConnection(strcon);
            string sqlQuery = @"SELECT * from Student";
            OleDbCommand cmd = new OleDbCommand(sqlQuery, con);
            OleDbDataAdapter da = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = new BindingSource(dt, null);

            DataGridViewButtonColumn btn = new DataGridViewButtonColumn();
            dataGridView1.Columns.Add(btn);
            btn.HeaderText = "Delete";
            btn.Text = "Delete";
            btn.Name = "btnDel";
            btn.UseColumnTextForButtonValue = true;
            dataGridView1.Columns[12].DisplayIndex = 0;

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 12)
            {
                int rowindex = dataGridView1.CurrentCell.RowIndex;

                OleDbConnection con = new OleDbConnection(strcon);
                con.Open();

                int rowID = int.Parse(dataGridView1.Rows[rowindex].Cells[0].Value.ToString());
                string qry = "DELETE FROM Student WHERE ID =" + rowID + "";
                OleDbCommand cmd = new OleDbCommand(qry, con);
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Record Delete Successfully");

                using (OleDbConnection newcon = new OleDbConnection(strcon))
                {
                    string sqlQuery = @"SELECT * from Student";
                    OleDbCommand cnd = new OleDbCommand(sqlQuery, newcon);
                    OleDbDataAdapter da = new OleDbDataAdapter(cnd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dataGridView1.DataSource = new BindingSource(dt, null);
                }
            }
        }
    }
}
