﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace studentfeemanagmentsystem
{
    public partial class inquery : Form
    {
        public inquery()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string connString = @"Data Source=localhost\SQLEXPRESS;Initial Catalog=mydatabase;Integrated Security=True;";
            using (SqlConnection sqlConn = new SqlConnection(connString))
            {
                string sqlQuery = @"SELECT * FROM studentdatabase WHERE Dates BETWEEN '18' AND '19'";
                SqlCommand cnd = new SqlCommand(sqlQuery, sqlConn);
                SqlDataAdapter da = new SqlDataAdapter(cnd);
                DataTable studentdatabase = new DataTable();
                da.Fill(studentdatabase);
                dataGridView1.DataSource = new BindingSource(studentdatabase, null);
            }
        }

        private void homeToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            welcome obj12 = new welcome();
            obj12.ShowDialog();
        }
    }
}
