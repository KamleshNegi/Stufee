﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace studentfeemanagmentsystem
{
    public partial class searchstudent : Form
    {
        public searchstudent()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {

                string connString = @"Data Source=localhost\SQLEXPRESS;Initial Catalog=mydatabase;Integrated Security=True;";
                using (SqlConnection sqlConn = new SqlConnection(connString))
                {
                    string sqlQuery = @"SELECT * from studentdatabase where StudentId='" + textBox1.Text + "'";
                    SqlCommand cnd = new SqlCommand(sqlQuery, sqlConn);
                    SqlDataAdapter da = new SqlDataAdapter(cnd);
                    DataTable studentdatabase = new DataTable();
                    da.Fill(studentdatabase);
                    dataGridView1.DataSource = new BindingSource(studentdatabase, null);

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                MessageBox.Show("Please Enter Number");
            }
       



            
            //string connString = @"Data Source=localhost\SQLEXPRESS;Initial Catalog=mydatabase;Integrated Security=True;";

            //using (SqlConnection sqlConn = new SqlConnection(connString))
            //{
            //    string sqlQuery = @"SELECT * from studentdatabase";
            //    SqlCommand cnd = new SqlCommand(sqlQuery, sqlConn);
            //    SqlDataAdapter da = new SqlDataAdapter(cnd);
            //    DataTable studentdatabase = new DataTable();
            //    da.Fill(studentdatabase);
            //    dataGridView1.DataSource = new BindingSource(studentdatabase, null);
            //}


        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }







    }
}