﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace studentfeemanagmentsystem
{
    public partial class TechRover : Form
    {
        string strcon = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|\\Techrover.mdb;Mode=ReadWrite;Persist Security Info=False";
        private int rowIndex = 0;
        private int tot, paid, remain;
        public TechRover()
        {
            InitializeComponent();
        }


        private void submissionfee_Load(object sender, EventArgs e)
        {
            OleDbConnection con = new OleDbConnection(strcon);
            string sqlQuery = @"SELECT * from Student";
            OleDbCommand cmd = new OleDbCommand(sqlQuery, con);
            OleDbDataAdapter da = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = new BindingSource(dt, null);
          
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            welcome obj2 = new welcome();
            obj2.ShowDialog();
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            OleDbConnection con = new OleDbConnection(strcon);
            try
            {
                int a = Convert.ToInt32(txtamount.Text);
                int b = Convert.ToInt32(txtpaid.Text);
                int c = Convert.ToInt32(txtremain.Text);

                con.Open();
                string qry = "insert into Student(Name,Contact,Email,Education,Course,Duration,Type,Jdate,Amount,Paid,Remain) Values('" + txtname.Text + "','" + txtcon.Text + "','" + txtmail.Text + "','" + txtedu.Text + "','" + cmbcourse.SelectedItem.ToString() + "','" + cmbduration.SelectedItem.ToString() + "','" + cmbtype.SelectedItem.ToString() + "','" + dateTimePicker1.Value.ToString("dd-MM-yyyy") + "','" + a + "','" + b + "','" + c + "')";
                OleDbCommand cmd = new OleDbCommand(qry, con);
                cmd.ExecuteNonQuery();
                con.Close();

                using (OleDbConnection newcon = new OleDbConnection(strcon))
                {
                    string sqlQuery = @"SELECT * from Student";
                    OleDbCommand cnd = new OleDbCommand(sqlQuery, newcon);
                    OleDbDataAdapter da = new OleDbDataAdapter(cnd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dataGridView1.DataSource = new BindingSource(dt, null);
                    MessageBox.Show("Account has been Created");
                    clear();
                }

            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                MessageBox.Show("Please Enter Numbers");
            }
               
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            txtname.Text = "";
            txtcon.Text = "";
            txtmail.Text = "";
            txtedu.Text = "";
            txtpaid.Text = "";
            txtamount.Text = "";
            txtremain.Text = "";
            cmbcourse.Text = "-- Select --";
            cmbtype.Text = "-- Select --";
            cmbduration.Text = "-- Select --";
            
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void txtpaid_TextChanged(object sender, EventArgs e)
        {
            if (txtamount.Text != "")
            {
                tot = Convert.ToInt32(txtamount.Text);
            }
            if (txtpaid.Text!="")
            {
               paid = Convert.ToInt32(txtpaid.Text);
            }
                
            remain = tot - paid;
            txtremain.Text = remain.ToString();
        }

        protected void clear()
        {
            txtname.Text = "";
            txtcon.Text = "";
            txtmail.Text = "";
            txtedu.Text = "";
            txtpaid.Text = "";
            txtamount.Text = "";
            txtremain.Text = "";
            cmbcourse.Text = "-- Select --";
            cmbtype.Text = "-- Select --";
            cmbduration.Text = "-- Select --";
            
        }

        private void dataGridView1_CellMouseUp(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                dataGridView1.Rows[e.RowIndex].Selected = true;
                rowIndex = e.RowIndex;
                dataGridView1.CurrentCell = dataGridView1.Rows[e.RowIndex].Cells[0];
               
                contextMenuStrip1.Show(dataGridView1, e.Location);
                contextMenuStrip1.Show(Cursor.Position);
            }
        }

 
        private void contextMenuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            try
	        {
	            ToolStripItem item = e.ClickedItem;

                if (e.ClickedItem.Text == "Delete")
                {
                    int rowindex = dataGridView1.CurrentCell.RowIndex;
                  
                   
                    OleDbConnection con = new OleDbConnection(strcon);
                    con.Open();
                    int rowID = int.Parse(dataGridView1.Rows[rowindex].Cells[0].Value.ToString());
                    string qry = "DELETE FROM Student WHERE ID ="+rowID+"";
                    OleDbCommand cmd = new OleDbCommand(qry, con);
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("Record Delete Successfully");

                    using (OleDbConnection newcon = new OleDbConnection(strcon))
                     {
                         string sqlQuery = @"SELECT * from Student";
                         OleDbCommand cnd = new OleDbCommand(sqlQuery, newcon);
                         OleDbDataAdapter da = new OleDbDataAdapter(cnd);
                         DataTable dt = new DataTable();
                         da.Fill(dt);
                         dataGridView1.DataSource = new BindingSource(dt, null);
                         btnUpdate.Visible = false;
                     } 
                }

                if (e.ClickedItem.Text == "Update")
                {
                    int rowindex = dataGridView1.CurrentCell.RowIndex;
                    int rowID = int.Parse(dataGridView1.Rows[rowindex].Cells[0].Value.ToString());

                    FillStudent(rowID);

                    btnDel.Visible = true;
                    button2.Visible = false;
                    button3.Visible = false;
                    buttonh.Visible = false;
                }
	        }
	    
            catch( Exception ex )
	        {
	            MessageBox.Show( ex.Message );
	        }
        }

        private void txtedu_TextChanged(object sender, EventArgs e)
        {
            cmbcourse.Focus();
        }

        protected void FillStudent(int id)
        {
            OleDbConnection con = new OleDbConnection(strcon);
            con.Open();


            string qry = "SELECT * FROM Student WHERE ID =" + id + "";

            OleDbDataAdapter adpt = new OleDbDataAdapter(qry, con);
            DataTable dt = new DataTable();
            adpt.Fill(dt);

            if (dt.Rows.Count > 0)
            {
                btnUpdate.Visible = true;
                clear();
                txtname.Text=dt.Rows[0][1].ToString();
                txtcon.Text = dt.Rows[0][2].ToString();
                txtmail.Text = dt.Rows[0][3].ToString();
                txtedu.Text = dt.Rows[0][4].ToString();
                cmbcourse.Text = dt.Rows[0][5].ToString();
                cmbduration.Text = dt.Rows[0][6].ToString();
                cmbtype.Text = dt.Rows[0][7].ToString();
                this.dateTimePicker1.Value = Convert.ToDateTime(dt.Rows[0][8].ToString());
                txtamount.Text = dt.Rows[0][9].ToString(); 
                txtpaid.Text = dt.Rows[0][10].ToString(); 
                txtremain.Text = dt.Rows[0][11].ToString();
                lblID.Text = dt.Rows[0][0].ToString();
            }
            con.Close();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
                OleDbConnection con = new OleDbConnection(strcon);
                con.Open();

                String strqry;
                Int32 id = Convert.ToInt32(lblID.Text);
                strqry = "UPDATE Student SET ";
                strqry += "Name='" + txtname.Text + "',";
                strqry += "Contact='" + txtcon.Text + "',";
                strqry += "Email='" + txtmail.Text + "',";
                strqry += "Education='" + txtedu.Text + "',";
                strqry += "Course='" + cmbcourse.SelectedItem.ToString() + "',";
                strqry += "Duration='" + cmbduration.SelectedItem.ToString() + "',";
                strqry += "Type='" + cmbtype.SelectedItem.ToString() + "',";
                strqry += "Jdate='" + dateTimePicker1.Value.ToString("dd-MM-yyyy") + "',";
                strqry += "Amount='" + txtamount.Text + "',";
                strqry += "Paid='" + txtpaid.Text + "',";
                strqry += "Remain='" + txtremain.Text + "' ";
                strqry += "where ID="+id+"";

                OleDbCommand cmd = new OleDbCommand(strqry,con);
                cmd.ExecuteNonQuery();
                con.Close();
               
                using (OleDbConnection newcon = new OleDbConnection(strcon))
                {
                    OleDbConnection con1 = new OleDbConnection(strcon);
                    con1.Open();

                    string sqlQuery = @"SELECT * from Student";
                    OleDbCommand cnd = new OleDbCommand(sqlQuery, newcon);
                    OleDbDataAdapter da = new OleDbDataAdapter(cnd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dataGridView1.DataSource = new BindingSource(dt, null);
                    MessageBox.Show("Account has been Update Successfully");
                    clear();
                    btnUpdate.Visible = false;
                    btnDel.Visible = false;
                    button2.Visible = true;
                    button3.Visible = true;
                    buttonh.Visible = true;
                }         
        }

        private void btnDel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
