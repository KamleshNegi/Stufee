﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace studentfeemanagmentsystem
{
    public partial class update : Form
    {
        public update()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();
            textBox7.Clear();
            textBox8.Clear();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            welcome obj7 = new welcome();
            obj7.ShowDialog();
        }

        private void update_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(@"Data Source=localhost\SQLEXPRESS;Initial Catalog=mydatabase;Integrated Security=True;");
                string cmd = ("UPDATE STUDENTDATABASE SET  UserName='" + textBox2.Text + "', FatheName='" + textBox3.Text + "', Program='" + textBox4.Text + "', Address='" + textBox5.Text + "', EmailAddress='" + textBox6.Text + "', CellNo='" + textBox7.Text + "', SubmissionFees = '" + textBox8.Text + "', Dates = '" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "'Where StudentId='" + textBox1.Text + "'");
                SqlCommand command = new SqlCommand(cmd, con);
                con.Open();
                command.ExecuteReader();
                con.Close();
                MessageBox.Show("Account has been Updated");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                MessageBox.Show("Please Enter Numbers");
            }

         
        }

        private void button5_Click(object sender, EventArgs e)
        {
            string connString = @"Data Source=localhost\SQLEXPRESS;Initial Catalog=mydatabase;Integrated Security=True;";
            using (SqlConnection sqlConn = new SqlConnection(connString))
            {
                string sqlQuery = @"SELECT * from studentdatabase";
                SqlCommand cnd = new SqlCommand(sqlQuery, sqlConn);
                SqlDataAdapter da = new SqlDataAdapter(cnd);
                DataTable studentdatabase = new DataTable();
                da.Fill(studentdatabase);
                dataGridView1.DataSource = new BindingSource(studentdatabase, null);


            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
