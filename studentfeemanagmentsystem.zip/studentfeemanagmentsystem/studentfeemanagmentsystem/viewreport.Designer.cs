﻿namespace studentfeemanagmentsystem
{
    partial class viewreport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnClose = new System.Windows.Forms.Button();
            this.btnunpaid = new System.Windows.Forms.Button();
            this.btnPaid = new System.Windows.Forms.Button();
            this.btnAll = new System.Windows.Forms.Button();
            this.btnPrint = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnClose
            // 
            this.btnClose.Image = global::studentfeemanagmentsystem.Properties.Resources.Actions_window_close_icon4;
            this.btnClose.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnClose.Location = new System.Drawing.Point(495, 55);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(109, 38);
            this.btnClose.TabIndex = 5;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnunpaid
            // 
            this.btnunpaid.Image = global::studentfeemanagmentsystem.Properties.Resources.Pen_icon;
            this.btnunpaid.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnunpaid.Location = new System.Drawing.Point(331, 55);
            this.btnunpaid.Name = "btnunpaid";
            this.btnunpaid.Size = new System.Drawing.Size(130, 38);
            this.btnunpaid.TabIndex = 3;
            this.btnunpaid.Text = "UnPaid Student";
            this.btnunpaid.UseVisualStyleBackColor = true;
            this.btnunpaid.Click += new System.EventHandler(this.btnunpaid_Click);
            // 
            // btnPaid
            // 
            this.btnPaid.Image = global::studentfeemanagmentsystem.Properties.Resources.money_icon;
            this.btnPaid.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnPaid.Location = new System.Drawing.Point(182, 55);
            this.btnPaid.Name = "btnPaid";
            this.btnPaid.Size = new System.Drawing.Size(124, 38);
            this.btnPaid.TabIndex = 12;
            this.btnPaid.Text = "Paid Student";
            this.btnPaid.UseVisualStyleBackColor = true;
            this.btnPaid.Click += new System.EventHandler(this.btnPaid_Click);
            // 
            // btnAll
            // 
            this.btnAll.Image = global::studentfeemanagmentsystem.Properties.Resources.earth_icon;
            this.btnAll.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAll.Location = new System.Drawing.Point(17, 55);
            this.btnAll.Name = "btnAll";
            this.btnAll.Size = new System.Drawing.Size(135, 38);
            this.btnAll.TabIndex = 1;
            this.btnAll.Text = "Complete View";
            this.btnAll.UseVisualStyleBackColor = true;
            this.btnAll.Click += new System.EventHandler(this.btnAll_Click);
            // 
            // btnPrint
            // 
            this.btnPrint.Location = new System.Drawing.Point(633, 55);
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.Size = new System.Drawing.Size(98, 37);
            this.btnPrint.TabIndex = 13;
            this.btnPrint.Text = "Print";
            this.btnPrint.UseVisualStyleBackColor = true;
            this.btnPrint.Click += new System.EventHandler(this.btnPrint_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(17, 145);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(714, 253);
            this.dataGridView1.TabIndex = 14;
            // 
            // viewreport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::studentfeemanagmentsystem.Properties.Resources.bgback;
            this.ClientSize = new System.Drawing.Size(755, 426);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.btnPrint);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnunpaid);
            this.Controls.Add(this.btnPaid);
            this.Controls.Add(this.btnAll);
            this.Name = "viewreport";
            this.Text = "viewreport";
            this.Load += new System.EventHandler(this.viewreport_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnAll;
        private System.Windows.Forms.Button btnPaid;
        private System.Windows.Forms.Button btnunpaid;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnPrint;
        private System.Windows.Forms.DataGridView dataGridView1;
    }
}