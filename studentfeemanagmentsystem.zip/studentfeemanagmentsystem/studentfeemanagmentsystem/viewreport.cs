﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;


namespace studentfeemanagmentsystem
{
    public partial class viewreport : Form
    {
        string strcon = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|\\Techrover.mdb;Mode=ReadWrite;Persist Security Info=False";
      
        public viewreport()
        {
            InitializeComponent();
        }

        private void viewreport_Load(object sender, EventArgs e)
        {
            disp();
        }

        protected void disp()
        {
            using (OleDbConnection newcon = new OleDbConnection(strcon))
            {
                OleDbConnection con = new OleDbConnection(strcon);
                con.Open();
                string sqlQuery = @"SELECT * from Student";
                OleDbCommand cnd = new OleDbCommand(sqlQuery, newcon);
                OleDbDataAdapter da = new OleDbDataAdapter(cnd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = new BindingSource(dt, null);

            }
        }

        private void btnAll_Click(object sender, EventArgs e)
        {
            using (OleDbConnection newcon = new OleDbConnection(strcon))
            {
                OleDbConnection con = new OleDbConnection(strcon);
                con.Open();
                string sqlQuery = @"SELECT * from Student";
                OleDbCommand cnd = new OleDbCommand(sqlQuery, newcon);
                OleDbDataAdapter da = new OleDbDataAdapter(cnd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = new BindingSource(dt, null);

            }
        }

        private void btnPaid_Click(object sender, EventArgs e)
        {
            using (OleDbConnection newcon = new OleDbConnection(strcon))
            {
                OleDbConnection con = new OleDbConnection(strcon);
                con.Open();
                string sqlQuery = @"SELECT * FROM Student where Remain=0";
                OleDbCommand cnd = new OleDbCommand(sqlQuery, newcon);
                OleDbDataAdapter da = new OleDbDataAdapter(cnd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = new BindingSource(dt, null);
            }
        }

        private void btnunpaid_Click(object sender, EventArgs e)
        {
            using (OleDbConnection newcon = new OleDbConnection(strcon))
            {
                OleDbConnection con = new OleDbConnection(strcon);
                con.Open();
                string sqlQuery = @"SELECT * from Student where Remain > 0";
                OleDbCommand cnd = new OleDbCommand(sqlQuery, newcon);
                OleDbDataAdapter da = new OleDbDataAdapter(cnd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = new BindingSource(dt, null);

            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

       

        private void btnPrint_Click(object sender, EventArgs e)
        {
            PrintDGV.Print_DataGridView(dataGridView1);
        }
       
       
    }
}
